import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 425;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signup7HB (56:29)
        width: double.infinity,
        height: 960*fem,
        decoration: BoxDecoration (
          color: Color(0xff362c4c),
        ),
        child: Stack(
          children: [
            Positioned(
              // backgroundambienceqiy (56:30)
              left: 0*fem,
              top: 143*fem,
              child: Align(
                child: SizedBox(
                  width: 733*fem,
                  height: 767*fem,
                  child: Image.asset(
                    'assets/page-1/images/background-ambience.png',
                    width: 733*fem,
                    height: 767*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // frame4jpM (56:34)
              left: 0*fem,
              top: 39*fem,
              child: Container(
                width: 425*fem,
                height: 860*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogrouppfyf4bj (USoUCBn8MKRp5rwbk3PFyF)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                      padding: EdgeInsets.fromLTRB(10*fem, 99*fem, 10*fem, 34*fem),
                      width: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0x3f000000),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupf3u785o (USoUXm3r3A1EWt5mguf3u7)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 189*fem, 39*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // back3iZ (56:59)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 2*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 28*fem,
                                      height: 28*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/back-tau.png',
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // signupY9X (56:60)
                                  'Sign Up',
                                  style: SafeGoogleFont (
                                    'Istok Web',
                                    fontSize: 48*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.44*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // namesBo (56:43)
                            margin: EdgeInsets.fromLTRB(28*fem, 0*fem, 0*fem, 3*fem),
                            child: Text(
                              'Name',
                              style: SafeGoogleFont (
                                'Istok Web',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.44*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupxzcznJm (USoUg1K78aupFkfa5mxZcZ)
                            margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 26*fem, 24*fem),
                            width: double.infinity,
                            height: 51*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupjgwyHmK (USoUpvDvVgjrjvoyrzjGWy)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 12*fem, 10*fem),
                                  width: 159*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffd9d9d9),
                                    borderRadius: BorderRadius.circular(20*fem),
                                  ),
                                  child: Text(
                                    'First Name',
                                    style: SafeGoogleFont (
                                      'Istok Web',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.44*ffem/fem,
                                      color: Color(0xff9e9b9b),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupbbp9keu (USoUwFNi4ZVjqJen2MBbp9)
                                  padding: EdgeInsets.fromLTRB(17*fem, 12*fem, 17*fem, 10*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffd9d9d9),
                                    borderRadius: BorderRadius.circular(20*fem),
                                  ),
                                  child: Text(
                                    'Last Name',
                                    style: SafeGoogleFont (
                                      'Istok Web',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.44*ffem/fem,
                                      color: Color(0xff9e9b9b),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // emailS1w (56:44)
                            margin: EdgeInsets.fromLTRB(28*fem, 0*fem, 0*fem, 3*fem),
                            child: Text(
                              'Email',
                              style: SafeGoogleFont (
                                'Istok Web',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.44*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // autogrouptxc1kHX (USoV4kADbrsBETj97KTXC1)
                            margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 26*fem, 21*fem),
                            padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 12*fem, 10*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9d9d9),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Text(
                              'Write your Email address here.',
                              style: SafeGoogleFont (
                                'Istok Web',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.44*ffem/fem,
                                color: Color(0xff9e9b9b),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupsfjdQcy (USoVAQfSu4hbaY1KtKSfJD)
                            margin: EdgeInsets.fromLTRB(26*fem, 0*fem, 161*fem, 5*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // passwordLFj (56:46)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                  child: Text(
                                    'Password',
                                    style: SafeGoogleFont (
                                      'Istok Web',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.44*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // mustcontain8characterse1X (56:52)
                                  margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                                  child: Text(
                                    '[must contain 8 characters]',
                                    style: SafeGoogleFont (
                                      'Istok Web',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.44*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouptpk18hP (USoVGpeRkQ5AGKnwyDTPk1)
                            margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 26*fem, 20*fem),
                            padding: EdgeInsets.fromLTRB(19*fem, 11*fem, 19*fem, 11*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9d9d9),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Text(
                              'Write your Password here.',
                              style: SafeGoogleFont (
                                'Istok Web',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.44*ffem/fem,
                                color: Color(0xff9e9b9b),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupkjyykim (USoVNKVGUggDRaBUu8KjYy)
                            margin: EdgeInsets.fromLTRB(11*fem, 0*fem, 29*fem, 24*fem),
                            padding: EdgeInsets.fromLTRB(23*fem, 12*fem, 23*fem, 10*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9d9d9),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Text(
                              'Re-enter Password.',
                              style: SafeGoogleFont (
                                'Istok Web',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.44*ffem/fem,
                                color: Color(0xff9e9b9b),
                              ),
                            ),
                          ),
                          Container(
                            // phonenumberPmj (56:45)
                            margin: EdgeInsets.fromLTRB(26*fem, 0*fem, 0*fem, 14*fem),
                            child: Text(
                              'Phone Number',
                              style: SafeGoogleFont (
                                'Istok Web',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.44*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // autogrouphhkbHs7 (USoVTEWkDkyVRvxENEHHKb)
                            margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 26*fem, 37*fem),
                            width: double.infinity,
                            height: 51*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupt1fbo4m (USoVaUofugVt3rC7gZt1Fb)
                                  padding: EdgeInsets.fromLTRB(0*fem, 8*fem, 7*fem, 14*fem),
                                  height: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // image1JXK (56:36)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 1*fem),
                                        width: 30*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-1.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Text(
                                        // cH7 (56:53)
                                        '+91 |',
                                        style: SafeGoogleFont (
                                          'Istok Web',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.44*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // rectangle22waH (56:41)
                                  width: 282*fem,
                                  height: 51*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(20*fem),
                                    border: Border.all(color: Color(0xa09747ff)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // signupbuttonTHj (56:54)
                            margin: EdgeInsets.fromLTRB(99*fem, 0*fem, 100*fem, 0*fem),
                            width: double.infinity,
                            height: 51*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xff6e39b6)),
                              color: Color(0x8e7b1dff),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Sign Up',
                                style: SafeGoogleFont (
                                  'Istok Web',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.44*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupbg53s6Z (USoW8t3MJBpRrSuXoEBG53)
                      margin: EdgeInsets.fromLTRB(20.5*fem, 0*fem, 0*fem, 0*fem),
                      width: 279*fem,
                      height: 29*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // byclickingonsignupyouagreetoou (56:57)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 279*fem,
                                height: 15*fem,
                                child: Text(
                                  'By clicking on sign up you agree to our Terms and Conditions.',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Istok Web',
                                    fontSize: 10*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.44*ffem/fem,
                                    color: Color(0x7fffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // tolearnaboutourtermsandconditi (56:58)
                            left: 0*fem,
                            top: 14*fem,
                            child: Align(
                              child: SizedBox(
                                width: 275*fem,
                                height: 15*fem,
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Istok Web',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.44*ffem/fem,
                                      color: Color(0x7fffffff),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'To Learn about our Terms and Conditions, tap on ',
                                      ),
                                      TextSpan(
                                        text: 'Learn More',
                                        style: SafeGoogleFont (
                                          'Istok Web',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.44*ffem/fem,
                                          color: Color(0xff6e39b6),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}