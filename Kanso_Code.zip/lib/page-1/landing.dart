import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 425;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // landingrYR (56:2)
        width: double.infinity,
        height: 960*fem,
        decoration: BoxDecoration (
          color: Color(0xff362c4c),
        ),
        child: Stack(
          children: [
            Positioned(
              // backgroundellipseesb (56:3)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 733*fem,
                  height: 1191*fem,
                  child: Image.asset(
                    'assets/page-1/images/background-ellipse.png',
                    width: 733*fem,
                    height: 1191*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // textframet1F (56:9)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                width: 573*fem,
                height: 913*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupzqdsmaq (USoSeu1a9Pv23Hbr6kZQds)
                      width: double.infinity,
                      height: 719.15*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse21uBF (56:10)
                            left: 141.3241271973*fem,
                            top: 114.8023681641*fem,
                            child: Align(
                              child: SizedBox(
                                width: 400.68*fem,
                                height: 370.61*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ellipse-21.png',
                                  width: 400.68*fem,
                                  height: 370.61*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse22qz1 (56:11)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 190*fem,
                                height: 179*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ellipse-22.png',
                                  width: 190*fem,
                                  height: 179*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse239jo (56:12)
                            left: 247.753692627*fem,
                            top: 527.1447753906*fem,
                            child: Align(
                              child: SizedBox(
                                width: 154.43*fem,
                                height: 155*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ellipse-23.png',
                                  width: 154.43*fem,
                                  height: 155*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // googlebuttoneAm (56:17)
                            left: 48*fem,
                            top: 566*fem,
                            child: Container(
                              width: 359*fem,
                              height: 91.76*fem,
                              decoration: BoxDecoration (
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0xff000000),
                                    offset: Offset(0*fem, 4*fem),
                                    blurRadius: 2*fem,
                                  ),
                                ],
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle10huj (56:18)
                                    left: 0*fem,
                                    top: 4.6463241577*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 359*fem,
                                        height: 81.31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(40*fem),
                                            border: Border.all(color: Color(0xff9747ff)),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // googleCLh (56:19)
                                    left: 15.931854248*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 59.48*fem,
                                        height: 91.76*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/google-7w7.png',
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // continuewithgoogleVah (56:20)
                                    left: 84.9704360962*fem,
                                    top: 31.3626708984*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 176*fem,
                                        height: 25*fem,
                                        child: Text(
                                          'Continue with Google',
                                          style: SafeGoogleFont (
                                            'Istok Web',
                                            fontSize: 17*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.44*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // facebookbuttonvg1 (56:21)
                            left: 48*fem,
                            top: 449*fem,
                            child: Container(
                              width: 359*fem,
                              height: 92.93*fem,
                              decoration: BoxDecoration (
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0xff000000),
                                    offset: Offset(0*fem, 4*fem),
                                    blurRadius: 2*fem,
                                  ),
                                ],
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle9QbB (56:22)
                                    left: 0*fem,
                                    top: 5.8077692986*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 359*fem,
                                        height: 81.31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(40*fem),
                                            border: Border.all(color: Color(0xff9747ff)),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // facebookV6q (56:23)
                                    left: 10.6213989258*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 69.04*fem,
                                        height: 92.93*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/facebook.png',
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // continuewithfacebookbvZ (56:24)
                                    left: 84.9704360962*fem,
                                    top: 32.5239257812*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 196*fem,
                                        height: 25*fem,
                                        child: Text(
                                          'Continue with Facebook',
                                          style: SafeGoogleFont (
                                            'Istok Web',
                                            fontSize: 17*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.44*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // takeyourmusicanywhereyougoGG1 (56:25)
                            left: 40.6945495605*fem,
                            top: 142.3514404297*fem,
                            child: Align(
                              child: SizedBox(
                                width: 266*fem,
                                height: 231*fem,
                                child: Text(
                                  'Take your music.\nAnywhere you go.',
                                  style: SafeGoogleFont (
                                    'Istok Web',
                                    fontSize: 40*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.44*ffem/fem,
                                    color: Color(0xffd9d9d9),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogrouprvyqJyP (USoTAYpqAkw3GG7zkTRVYq)
                      padding: EdgeInsets.fromLTRB(80.69*fem, 123.21*fem, 154.27*fem, 0*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogrouptpeuQWd (USoT1yEnwVZj9jktfQtPEu)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22.65*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // line1K7o (56:13)
                                  margin: EdgeInsets.fromLTRB(0*fem, 2.06*fem, 24.01*fem, 0*fem),
                                  width: 140.09*fem,
                                  height: 1.18*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/line-1.png',
                                    width: 140.09*fem,
                                    height: 1.18*fem,
                                  ),
                                ),
                                Container(
                                  // or1FX (56:16)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18.85*fem, 0*fem),
                                  child: Text(
                                    'Or',
                                    style: SafeGoogleFont (
                                      'Istok Web',
                                      fontSize: 13*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.44*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // line2vNV (56:14)
                                  margin: EdgeInsets.fromLTRB(0*fem, 1.28*fem, 0*fem, 0*fem),
                                  width: 140.09*fem,
                                  height: 0.4*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/line-2.png',
                                    width: 140.09*fem,
                                    height: 0.4*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // loginRq3 (56:15)
                            margin: EdgeInsets.fromLTRB(1.57*fem, 0*fem, 0*fem, 0*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Text(
                                'Log in',
                                style: SafeGoogleFont (
                                  'Istok Web',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.44*ffem/fem,
                                  color: Color(0xa5ffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // signupbuttonWrV (56:26)
              left: 41*fem,
              top: 682*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 354*fem,
                  height: 70*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0x309747ff)),
                    borderRadius: BorderRadius.circular(40*fem),
                    gradient: LinearGradient (
                      begin: Alignment(1, 0),
                      end: Alignment(-1.064, -2.714),
                      colors: <Color>[Color(0xe59747ff), Color(0xe59747ff), Color(0xe59747ff), Color(0xe59747ff)],
                      stops: <double>[0.104, 0.74, 0.899, 1],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xff000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 25*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Sign Up for Free',
                      style: SafeGoogleFont (
                        'Istok Web',
                        fontSize: 17*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.44*ffem/fem,
                        color: Color(0xff1e1e1e),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}