import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 425;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginr5X (56:61)
        width: double.infinity,
        height: 960*fem,
        decoration: BoxDecoration (
          color: Color(0xff362c4c),
        ),
        child: Stack(
          children: [
            Positioned(
              // backgroundambienceAru (56:62)
              left: 0*fem,
              top: 143*fem,
              child: Align(
                child: SizedBox(
                  width: 733*fem,
                  height: 932*fem,
                  child: Image.asset(
                    'assets/page-1/images/background-ambience-XMB.png',
                    width: 733*fem,
                    height: 932*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // frame4Tr1 (56:68)
              left: 28*fem,
              top: 122*fem,
              child: Container(
                width: 341*fem,
                height: 677*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // backmbo (56:79)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 313*fem, 168*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 28*fem,
                          height: 28*fem,
                          child: Image.asset(
                            'assets/page-1/images/back.png',
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // welcomebackfSH (56:74)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 55*fem, 22*fem),
                      constraints: BoxConstraints (
                        maxWidth: 176*fem,
                      ),
                      child: Text(
                        'Welcome Back!',
                        style: SafeGoogleFont (
                          'Istok Web',
                          fontSize: 40*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.44*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupddtkZ1s (USoWqSi6VfRsoWFvPDDdTK)
                      margin: EdgeInsets.fromLTRB(28*fem, 0*fem, 0*fem, 14*fem),
                      width: 313*fem,
                      height: 70*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Center(
                        child: Text(
                          'Username or Email Address',
                          style: SafeGoogleFont (
                            'Istok Web',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.44*ffem/fem,
                            color: Color(0xff949494),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupbbjjd1j (USoWuXRdQ9aKsjaQcsbBjj)
                      margin: EdgeInsets.fromLTRB(28*fem, 0*fem, 0*fem, 15*fem),
                      padding: EdgeInsets.fromLTRB(23*fem, 22*fem, 23*fem, 19*fem),
                      width: 313*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Text(
                        'Password',
                        style: SafeGoogleFont (
                          'Istok Web',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.44*ffem/fem,
                          color: Color(0xff949494),
                        ),
                      ),
                    ),
                    Container(
                      // diveinbuttonGqP (56:71)
                      margin: EdgeInsets.fromLTRB(28*fem, 0*fem, 0*fem, 7*fem),
                      width: 313*fem,
                      height: 70*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0x309747ff)),
                        borderRadius: BorderRadius.circular(40*fem),
                        gradient: LinearGradient (
                          begin: Alignment(1, 0),
                          end: Alignment(-1.064, -2.714),
                          colors: <Color>[Color(0xe59747ff), Color(0xe59747ff), Color(0xe59747ff), Color(0xe59747ff)],
                          stops: <double>[0.104, 0.74, 0.899, 1],
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'Dive-In',
                          style: SafeGoogleFont (
                            'Istok Web',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.44*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // forgotpasswordSNV (56:78)
                      margin: EdgeInsets.fromLTRB(46*fem, 0*fem, 0*fem, 49*fem),
                      child: Text(
                        'Forgot Password?',
                        style: SafeGoogleFont (
                          'Istok Web',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.44*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // orcontinuewithjsP (56:73)
                      margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 0*fem),
                      child: Text(
                        'Or Continue with',
                        style: SafeGoogleFont (
                          'Istok Web',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.44*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // facebookFaq (56:80)
              left: 155*fem,
              top: 812*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/facebook-9oP.png',
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            Positioned(
              // googlemZB (56:81)
              left: 212*fem,
              top: 812*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/google.png',
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            Positioned(
              // pixelcathBw (56:82)
              left: 163*fem,
              top: 170*fem,
              child: Align(
                child: SizedBox(
                  width: 90*fem,
                  height: 90*fem,
                  child: Image.asset(
                    'assets/page-1/images/pixel-cat.png',
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}